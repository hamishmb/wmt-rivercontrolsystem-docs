# WMT River System virtual machines README

Author: Patrick Wigmore

## Rough instructions

### To install the virtual machines:

1. If you have already installed these virtual machines, or a previous version, remove the existing copies of them from VirtualBox. (Choosing either to keep or delete the underlying files, depending on your well-informed preference.)

2. Place the "WMT River System" directory in a location where you intend to run the machines from. For example, you could place it in ~/.VirtualBox/Machines/, or on an external hard drive.

3. Create a "Host-only Network" "vboxnet1" in VirtualBox. Use the IPv4 address 192.168.0.1 and IPv4 subnet mask 255.255.255.0. In the GUI, go to File > Preferences > Network > Host-only Networks and click the button to add a new host-only network.

    **NOTE:** If you already have a "vboxnet1" host-only network in use for some other purpose, then your new network will need to have a different name. You can change the settings on each machine to match it.

    **IMPORTANT:** If your host is already connected to a network with the same subnet as the Raspberry Pi network, then you should set up an Internal Network instead, else there may be address conflicts or routing problems.

4. Open the WMT River System/River system base image/River system base iamge.vbox file in VirtualBox. Typically, this will be the default file open action for .vbox files on a desktop system with VirtualBox installed. This will load the disk images for all of the other VMs.

5. **Only after loading the base image VM into VirtualBox** open all the remaining .vbox files from the other WMT River System/ subdirectories.

6. Check the network adapter settings of the virtual machines. For the NAS Box, the first adapter should be connected to NAT, and the second to Host-only Network "vboxnet1". For the Pis, the first adapter is connected to "vboxnet1" and the second to NAT. (Sorry for the inconsistency.)

    **NOTE:** If you are not using vboxnet1, select the appropriate network instead.


### To use the virtual machines:

The NAT Box is undocumented here. Ask Hamish!

The Pi VMs are configured to be as similar as possible to the equivalent real Raspberry Pis. They will autostart the river system software in testing mode.

The "headless start" and "detachable start" options may be useful.

If you use the suggested Host-only Network configuration, you can SSH into the Pis using their 192.168.0.x IP addresses using an ordinary terminal window on the host machine. On the virtual network, the host machine has the IP address specified in the Host-only Network configuration. (i.e. 192.168.0.1)

If you do not use the suggested Host-only network configuration, you can still access the Pi VMs through their consoles in the VirtualBox GUI. Kill the river control system software to drop to a bash prompt.

Alternatively, you could swap the second interface of each Pi from NAT to the default vboxnet0 Host-only network, which has a DHCP server handing out IP addresses. Find out what subnet it is using (e.g. 192.168.56.0/24) and then run, e.g.

    nmap -A -T4 192.168.56.0/24

To reveal the IP addresses of the Pis. (Or run `ip addr show` on the console of a specific Pi.)


## What is this?

Enclosed are ten virtual macines (VMs) representing components in the Wimborne Model Town River Control System.

One of the virtual machines represents the NAS box. This is more or less a direct clone of a VM created previously by Hamish. This document does not describe that machine in much detail, because the author lacks insight into it.

The other nine VMs represent the Raspberry Pis. They are configured to be as similar to the real Raspberry Pis as is reasonably practicable, so that they can be used for test and development of the river control system software.

The Raspberry Pi VMs are all based on the VM named "River system base image", which is fairly similar in concept to the base SD card image described in the installation specification.

Due to the amount of duplication involved in cloning the base image eight times, the other eight VMs make use of VirtualBox's multi-attach storage feature. This allows multiple virtual machines to share the same disk image file, which is treated as immutable. Any changes made to the individaul virtual disk of each machine are stored in a differencing image associated with that machine, so each machine has its own state. Since the VMs differ very little from the base image, this saves a lot of disk space on the host machine.

In addition to using multi-attach, the disk images are also attached using VirtualBox's "discard=on" option and the guest filesystems mounted with the "discard" option. This means that the disk image files on the host can shrink instead of only ever growing.

(See https://gist.github.com/stoneage7/9df39cfac2c28932ed86)
